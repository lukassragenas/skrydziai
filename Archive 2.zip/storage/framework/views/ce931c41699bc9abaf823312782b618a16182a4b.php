<?php $__env->startSection('content'); ?>

    <section class="home-section d-flex align-items-top">
        <div class="container">
            <div class="row py-5 fade-right">
                <div class="col-md-12 mx-auto my-5 text-white text-uppercase">
                    <div class="my-profile pt-5">
                        <div class="container-fluid mt-5">
                            <?php if(\Session::has('msg')): ?>
                                <div class="alert alert-success">
                                    <?php echo \Session::get('msg'); ?>

                                </div>
                            <?php endif; ?>
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="ticket-tab" href="<?php echo e(route('reserved')); ?>">Mano
                                        rezervuoti bilietai</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="ticket1-tab" href="<?php echo e(route('paid')); ?>">Mano apmokėti
                                        bilietai</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="prifle-tab" href="<?php echo e(route('profile')); ?>">Profilio
                                        redagavimas</a>
                                </li>
                            </ul>
                            <div class="card p-3" id="myTabContent">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th class="align-middle" scope="col">Skrydis</th>
                                            <th class="align-middle" scope="col">Išvykimo data</th>
                                            <th class="align-middle" scope="col">Iš oro uosto</th>
                                            <th class="align-middle" scope="col">Į oro uosto</th>
                                            <th class="align-middle" scope="col">Statusas</th>
                                            <th class="align-middle" scope="col">Kaina</th>
                                            <th class="align-middle" scope="col">Pirkti</th>
                                            <th class="align-middle" scope="col">Atšaukti rezervaciją</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $ticketsReserved; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="align-middle"><?php echo e($ticket->flight->id); ?></td>
                                                <td class="align-middle"><?php echo e($ticket->flight->departure_time); ?></td>
                                                <td class="align-middle"><?php echo e($ticket->flight->airport_from->name); ?></td>
                                                <td class="align-middle"><?php echo e($ticket->flight->airport_to->name); ?></td>
                                                <td class="align-middle"><?php echo e($ticket->status); ?></td>
                                                <td class="align-middle"><?php echo e($ticket->flight->tickets_price); ?> €</td>
                                                <td class="align-middle">
                                                    <button type="button" class="primary-btn-2" data-toggle="modal"
                                                        data-target="#modal<?php echo e($ticket->id); ?>">
                                                        Pirkti bilietą
                                                    </button>
                                                    <div class="modal fade" id="modal<?php echo e($ticket->id); ?>" tabindex="-1"
                                                        role="dialog" aria-labelledby="modalLabel-<?php echo e($ticket->id); ?>"
                                                        aria-hidden="true">
                                                        <div class="modal-dialog modal-lg" role="document">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title"
                                                                        id="ModalLabel-<?php echo e($ticket->id); ?>">
                                                                        Apmokėjimas</h5>
                                                                </div>
                                                                <form role="form" action="<?php echo e(route('stripe.post')); ?>"
                                                                    method="post"
                                                                    class="require-validation<?php echo e($ticket->id); ?>"
                                                                    data-cc-on-file="false"
                                                                    data-stripe-publishable-key="<?php echo e(env('STRIPE_KEY')); ?>"
                                                                    id="payment-form-<?php echo e($ticket->id); ?>">
                                                                    <?php echo csrf_field(); ?>
                                                                    <input type="hidden" name="ticket_id"
                                                                        value="<?php echo e($ticket->id); ?>">
                                                                    <div class="modal-body">
                                                                        <div class="custom-control custom-checkbox">
                                                                            <input type="checkbox"
                                                                                class="custom-control-input"
                                                                                id="customCheck-<?php echo e($ticket->id); ?>"
                                                                                name="example1">
                                                                            <label class="custom-control-label"
                                                                                for="customCheck-<?php echo e($ticket->id); ?>">Domina
                                                                                kelionės draudimas?Nerizikuokite!
                                                                                Apsidrauskite
                                                                                medicininių išlaidų ar nelaimingų atsitikimų
                                                                                draudimu
                                                                                visos kelionės metu ir išvenkite
                                                                                rūpesčių.</label>
                                                                        </div>
                                                                        <hr>
                                                                        <div class="form-group">
                                                                            <label for="price"
                                                                                class="control-label pl-2">Dabartinė
                                                                                kelionės
                                                                                kaina:</label>
                                                                            <input style="color:#000 !important" type="text"
                                                                                readonly class="form-control-plaintext"
                                                                                id="price-<?php echo e($ticket->id); ?>" name="price"
                                                                                value="<?php echo e($ticket->flight->tickets_price); ?>">
                                                                        </div>
                                                                        <hr>
                                                                        <div class='form-row row'>
                                                                            <div class='col-lg-6 form-group required'>
                                                                                <label class='control-label'>Vardas</label>
                                                                                <input class='form-control'
                                                                                    style="width: 367px !important"
                                                                                    type='text'>
                                                                            </div>
                                                                            <div class='col-lg-6 form-group required'>
                                                                                <label class='control-label'>Kortelės
                                                                                    nr.</label>
                                                                                <input autocomplete='off'
                                                                                    class='form-control card-number<?php echo e($ticket->id); ?>'
                                                                                    type='text'
                                                                                    style="width: 367px !important">
                                                                            </div>
                                                                        </div>

                                                                        <div class='form-row row mt-4'>
                                                                            <div
                                                                                class='col-xs-12 col-md-4 form-group cvc required'>
                                                                                <label class='control-label'>CVC</label>
                                                                                <input autocomplete='off'
                                                                                    class='form-control card-cvc<?php echo e($ticket->id); ?>'
                                                                                    placeholder='ex. 311' size='4'
                                                                                    type='text'>
                                                                            </div>
                                                                            <div
                                                                                class='col-xs-12 col-md-4 form-group expiration required'>
                                                                                <label class='control-label'>Galiojimo
                                                                                    mėn</label> <input
                                                                                    class='form-control card-expiry-month<?php echo e($ticket->id); ?>'
                                                                                    placeholder='MM' size='2' type='text'>
                                                                            </div>
                                                                            <div
                                                                                class='col-xs-12 col-md-4 form-group expiration required'>
                                                                                <label class='control-label'>Galiojimo
                                                                                    metai</label>
                                                                                <input
                                                                                    class='form-control card-expiry-year<?php echo e($ticket->id); ?>'
                                                                                    placeholder='YYYY' size='4' type='text'>
                                                                            </div>
                                                                        </div>

                                                                        <div class='form-row row'>
                                                                            <div class='col-md-12 error form-group d-none'>
                                                                                <div class='alert-danger alert'>Įveskite
                                                                                    teisingus duomenis ir bandykite dar
                                                                                    kartą</div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <script>
                                                                        let price<?php echo e($ticket->id); ?> = $('#payment-form-<?php echo e($ticket->id); ?> #price-<?php echo e($ticket->id); ?>').val();
                                                                        $('#customCheck-<?php echo e($ticket->id); ?>').change(function() {
                                                                            if ($(this).is(":checked")) {
                                                                                let newPrice = price<?php echo e($ticket->id); ?> * 1.05;
                                                                                var amt = parseFloat(newPrice);
                                                                                $('#payment-form-<?php echo e($ticket->id); ?> #price-<?php echo e($ticket->id); ?>').val(amt.toFixed(2));
                                                                            } else {
                                                                                $('#payment-form-<?php echo e($ticket->id); ?> #price-<?php echo e($ticket->id); ?>').val(price<?php echo e($ticket->id); ?>);
                                                                            }
                                                                        });
                                                                    </script>
                                                                    <script type="text/javascript">
                                                                        $(function() {
                                                                            var $form = $(".require-validation<?php echo e($ticket->id); ?>");
                                                                            $('form.require-validation<?php echo e($ticket->id); ?>').bind('submit', function(e) {
                                                                                var $form = $(".require-validation<?php echo e($ticket->id); ?>"),
                                                                                    inputSelector = ['input[type=email]', 'input[type=password]',
                                                                                        'input[type=text]', 'input[type=file]',
                                                                                        'textarea'
                                                                                    ].join(', '),
                                                                                    $inputs = $form.find('.required').find(inputSelector),
                                                                                    $errorMessage = $form.find('div.error'),
                                                                                    valid = true;
                                                                                $errorMessage.addClass('d-none');

                                                                                $('.has-error').removeClass('has-error');
                                                                                $inputs.each(function(i, el) {
                                                                                    var $input = $(el);
                                                                                    if ($input.val() === '') {
                                                                                        $input.parent().addClass('has-error');
                                                                                        $errorMessage.removeClass('d-none');
                                                                                        e.preventDefault();
                                                                                    }
                                                                                });

                                                                                if (!$form.data('cc-on-file')) {
                                                                                    e.preventDefault();
                                                                                    Stripe.setPublishableKey($form.data('stripe-publishable-key'));
                                                                                    Stripe.createToken({
                                                                                        number: $('.card-number<?php echo e($ticket->id); ?>').val(),
                                                                                        cvc: $('.card-cvc<?php echo e($ticket->id); ?>').val(),
                                                                                        exp_month: $('.card-expiry-month<?php echo e($ticket->id); ?>').val(),
                                                                                        exp_year: $('.card-expiry-year<?php echo e($ticket->id); ?>').val()
                                                                                    }, stripeResponseHandler);
                                                                                }

                                                                            });

                                                                            function stripeResponseHandler(status, response) {
                                                                                if (response.error) {
                                                                                    $('.error')
                                                                                        .removeClass('d-none')
                                                                                        .find('.alert')
                                                                                        .text(response.error.message);
                                                                                } else {
                                                                                    // token contains id, last4, and card type
                                                                                    var token = response['id'];
                                                                                    // insert the token into the form so it gets submitted to the server
                                                                                    $form.find('input[type=text]').empty();
                                                                                    $form.append("<input type='hidden' name='stripeToken' value='" + token + "'/>");
                                                                                    $form.get(0).submit();
                                                                                }
                                                                            }
                                                                        });
                                                                    </script>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="primary-btn-3 mr-4"
                                                                            data-dismiss="modal">Atšaukti</button>
                                                                        <button type="submit"
                                                                            class="primary-btn">Apmokėti</button>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td class="align-middle">
                                                    <form action="<?php echo e(route('delete', ['id' => $ticket->id])); ?>"
                                                        method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" value="<?php echo e($ticket->id); ?>">
                                                        <button type="submit" class="primary-btn">Atšaukti
                                                            rezervaciją</button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <?php echo e($ticketsReserved->links('vendor.pagination.bootstrap-4')); ?>

                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="https://js.stripe.com/v2/"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/lukas/Downloads/skrydziai-master/resources/views/pages/profile.blade.php ENDPATH**/ ?>