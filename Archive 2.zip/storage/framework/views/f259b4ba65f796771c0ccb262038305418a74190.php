<?php $__env->startSection('content'); ?>
    <section class="home-section d-flex align-items-top">
        <div class="container">
            <div class="row py-5 fade-right">
                <div class="col-md-12 mx-auto my-5 text-white text-uppercase">
                    <div class="my-profile pt-5">
                        <div class="container-fluid mt-5">
                            <?php if(\Session::has('msg')): ?>
                                <div class="alert alert-success">
                                    <?php echo \Session::get('msg'); ?>

                                </div>
                            <?php endif; ?>
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link" id="ticket-tab" href="<?php echo e(route('reserved')); ?>">Mano
                                        rezervuoti bilietai</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="ticket1-tab" href="<?php echo e(route('paid')); ?>">Mano apmokėti
                                        bilietai</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link active" id="prifle-tab" href="<?php echo e(route('profile')); ?>">Profilio
                                        redagavimas</a>
                                </li>
                            </ul>
                            <div class="card p-3" id="myTabContent">
                                <div class="row container p-3">
                                    <form action="<?php echo e(route('email')); ?>" method="POST" class="col-6">
                                        <?php echo csrf_field(); ?>
                                        <h2>El. pašto keitimas</h2>
                                        <div class="form-group row align-items-center">
                                            <label for="staticEmail" class="col-form-label">Esamas el. pašto
                                                adresas</label>
                                            <div class="col-sm-10 m-0 p-0">
                                                <input type="text" readonly class="form-control-plaintext" id="staticEmail"
                                                    value="<?php echo e(auth()->user()->email); ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="formGroupExampleInput">Naujas el pašto adresas</label>
                                            <input type="email" class="form-control" id="formGroupExampleInput"
                                                name="email">
                                        </div>
                                        <button type="submit" class="primary-btn">Atnaujinti</button>
                                    </form>
                                    <form action="<?php echo e(route('password')); ?>" method="POST" class="col-6">
                                        <?php echo csrf_field(); ?>
                                        <h2>Slaptažodžio keitimas</h2>
                                        <div class="form-group">
                                            <label for="formGroupExampleInput1">Naujas slaptažodis</label>
                                            <input type="password" class="form-control" name="password" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="formGroupExampleInput2">Pakartokite naują slaptažodį</label>
                                            <input type="password" class="form-control" name="password_confirmation"
                                                required>
                                        </div>
                                        <button type="submit" class="primary-btn">Atnaujinti</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/lukas/Downloads/skrydziai-master/resources/views/pages/account.blade.php ENDPATH**/ ?>