    <nav class="navbar">
        <div class="left-col">
            <a href="<?php echo e(route('home')); ?>"> <img class="logo" src="/storage/images/logo-white.png">
            </a>
        </div>
        <div class="right-col">
            <ul>
                <li><a class="<?php echo e(request()->is('/') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">Bilietų
                        paieška</a>
                </li>
                <?php if(Route::has('login')): ?>
                    <?php if(auth()->guard()->check()): ?>
                        <li><a class="<?php echo e(request()->is('mano-profilis') ? 'active' : ''); ?>"
                                href="<?php echo e(route('profile')); ?>">Mano profilis</a></li>
                    <?php else: ?>
                        <li><a class="<?php echo e(request()->is('login') ? 'active' : ''); ?>"
                                href="<?php echo e(route('login')); ?>">Prisijungimas</a>
                        </li>

                        <?php if(Route::has('register')): ?>
                            <li><a class="<?php echo e(request()->is('register') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('register')); ?>">Registracija</a></li>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
                <li><a class="<?php echo e(request()->is('pagalba') ? 'active' : ''); ?>"
                        href="<?php echo e(route('support')); ?>">Pagalba</a>
                </li>
                <?php if(auth()->guard()->check()): ?>
                    <li>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>

                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.responsive-nav-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                                                                    this.closest(\'form\').submit();']]); ?>
<?php $component->withName('responsive-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                                                                    this.closest(\'form\').submit();']); ?>
                                <?php echo e(__('Atsijungti')); ?>

                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
        </div>

    </nav>
<?php /**PATH /Users/lukas/Downloads/skrydziai-master/resources/views/partials/header.blade.php ENDPATH**/ ?>