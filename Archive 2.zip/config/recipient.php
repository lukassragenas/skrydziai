<?php

return [
    'email' => env('RECIPIENT_EMAIL'),
    'name' => env('RECIPIENT_NAME'),
];
