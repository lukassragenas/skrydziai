<?php $__env->startSection('content'); ?>

    <section class="home-section d-flex align-items-center">
        <div class="container">
            <div class="row py-5">
                <div class="col-md-12 mx-auto my-5 text-white text-uppercase row justify-content-center">
                    <div class="login-form register-add fade-right">

                        <div class="header">Pagalbos centras</div>
                        <?php if(session()->has('message')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session()->get('message')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <form action="<?php echo e(route('send.email')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            Sveiki, susisiekite su mumis, atsakymą gausite per 24 valandas!</br></br>
                            <input class="mb-5" type="email" name="email" placeholder="El. paštas">
                            <input class="mb-5" type="text" name="subject" placeholder="Tema">
                            <textarea class="mb-5 p-3" name="content" placeholder="Jūsų pranešimas"></textarea>
                            <input class="mt-4 w-100" type="submit" value="Siųsti">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/lukas/Downloads/skrydziai-master/resources/views/pages/support.blade.php ENDPATH**/ ?>