<?php $__env->startSection('content'); ?>
    <section class="home-section d-flex align-items-top">
        <div class="container">
            <div class="row py-5 fade-right">
                <div class="col-md-12 mx-auto my-5 text-white text-uppercase">
                    <div class="my-profile pt-5">
                        <div class="container mt-5">
                            <?php if(\Session::has('msg')): ?>
                                <div class="alert alert-success">
                                    <?php echo \Session::get('msg'); ?>

                                </div>
                            <?php endif; ?>
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">Nr.</th>
                                        <th scope="col">Išvykimo data</th>
                                        <th scope="col">Atvykimo data</th>
                                        <th scope="col">Statusas</th>
                                        <?php if(auth()->guard()->check()): ?>
                                            <th scope="col">Klasė</th>
                                            <th scope="col">Rezervuotis</th>
                                        <?php endif; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $flights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($loop->index + 1); ?></th>
                                            <td><?php echo e($flight->departure_time); ?></td>
                                            <td><?php echo e($flight->arrival_time); ?></td>
                                            <td><?php echo e($flight->status); ?></td>
                                            <?php if(auth()->guard()->check()): ?>
                                                <form action="<?php echo e(route('reserve')); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="flight_id" value="<?php echo e($flight->id); ?>">
                                                    <td>
                                                        <div class="form-group">
                                                            <select name="seat_class" class="form-control">
                                                                <option value="ekonomine">Ekonominė</option>
                                                                <option value="pirma">Pirma</option>
                                                                <option value="verslo">Verslo</option>
                                                            </select>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <button type="submit" class="primary-btn">Rezervuoti</button>
                                                    </td>
                                                </form>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/lukas/Downloads/skrydziai-master/resources/views/pages/flights.blade.php ENDPATH**/ ?>